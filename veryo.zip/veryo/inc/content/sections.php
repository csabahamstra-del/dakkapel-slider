<?php
/**
 * Terugkerende secties als block markup. Dezelfde functies voeden de block patterns
 * en de pagina-inhoud die bij activatie wordt aangemaakt.
 *
 * @package Veryo
 */

defined( 'ABSPATH' ) || exit;

/**
 * Relatieve URL naar een pagina van het thema (werkt vóór en na het aanmaken van pagina's).
 *
 * @param string $path Pad.
 * @return string
 */
function veryo_link( $path ) {
	$path = trim( $path, '/' );
	return '' === $path ? home_url( '/' ) : home_url( '/' . $path . '/' );
}

/**
 * Hero op petrol met groot vinkje.
 *
 * @param string                       $title    H1.
 * @param string                       $sub      Subregel.
 * @param array<int,array<int,string>> $buttons  Knoppen.
 * @param string                       $extra    Extra blokken onder de knoppen.
 * @param string                       $css_class Extra class voor de hero.
 * @return string
 */
function veryo_sec_hero( $title, $sub, $buttons = array(), $extra = '', $css_class = '' ) {
	$inner  = veryo_b_h( $title, 1, array( 'fontSize' => 'display-xl' ) );
	$inner .= veryo_b_p( $sub, array( 'className' => 'veryo-lead' ) );
	if ( $buttons ) {
		$inner .= veryo_b_buttons( $buttons );
	}
	$inner .= $extra;
	return veryo_b_group(
		$inner,
		array(
			'tagName'   => 'section',
			'align'     => 'full',
			'className' => trim( 'is-style-petrol veryo-hero has-check ' . $css_class ),
		)
	);
}

/**
 * Feitenbalk onder de hero: vier korte, controleerbare feiten.
 *
 * @param array<int,array<int,string>> $facts Lijst van array( label, waarde ).
 * @return string
 */
function veryo_sec_facts( $facts ) {
	$cols = array();
	foreach ( $facts as $fact ) {
		$cols[] = veryo_b_p( esc_html( $fact[0] ) ) . veryo_b_p( esc_html( $fact[1] ) );
	}
	return veryo_b_columns( $cols, array( 'className' => 'veryo-facts' ) );
}

/**
 * Sectiekop over de volle breedte: kop links, inleiding rechts.
 *
 * @param string $title Kop (H2).
 * @param string $intro Inleiding (blokken; leeg = alleen kop).
 * @return string
 */
function veryo_sec_head( $title, $intro = '' ) {
	return veryo_b_columns(
		array(
			array(
				'width' => '50%',
				'inner' => veryo_b_h( $title ),
			),
			array(
				'width' => '50%',
				'inner' => $intro,
			),
		),
		array( 'className' => 'veryo-head' )
	);
}

/**
 * Brede sectie op de homepage of een overzichtspagina.
 *
 * @param string $inner     Inhoud.
 * @param string $css_class Extra class.
 * @param string $anchor    Optioneel anker.
 * @return string
 */
function veryo_sec_wide( $inner, $css_class = '', $anchor = '' ) {
	$attrs = array(
		'align'     => 'wide',
		'className' => trim( 'veryo-section ' . $css_class ),
		'layout'    => false,
	);
	if ( $anchor ) {
		$attrs['anchor'] = $anchor;
	}
	return veryo_b_group( $inner, $attrs );
}

/**
 * Het direct-antwoordblok bovenaan dienst-, regio- en branchepagina's.
 *
 * @param string $text Antwoord in 2–3 zinnen.
 * @return string
 */
function veryo_sec_answer( $text ) {
	return veryo_b_group(
		veryo_b_p( $text, array( 'fontSize' => 'body-l' ) ),
		array( 'className' => 'is-style-answer veryo-answer' )
	);
}

/**
 * Foto uit de fotobibliotheek. Staat de foto niet in het thema, dan komt er niets:
 * geen lege plek of placeholder op de site.
 *
 * @param string $desc Omschrijving van de gewenste foto (ter referentie voor wie later foto's toevoegt).
 * @param string $alt  Alt-tekst (met het hoofdzoekwoord van de pagina).
 * @param string $key  Sleutel uit veryo_photo_library().
 * @return string
 */
function veryo_sec_photo( $desc, $alt, $key = '' ) {
	unset( $desc );
	$id = $key ? veryo_photo_id( $key ) : 0;
	return $id ? veryo_b_image( $id, $alt ) : '';
}

/**
 * Kop met alinea's en optioneel een lijst.
 *
 * @param string   $title Kop (H2).
 * @param string[] $paras Alinea's.
 * @param string[] $items Lijstitems.
 * @param string   $style Lijststijl: '', 'checks'.
 * @return string
 */
function veryo_sec_text( $title, $paras = array(), $items = array(), $style = '' ) {
	$out = $title ? veryo_b_h( $title ) : '';
	foreach ( $paras as $para ) {
		$out .= veryo_b_p( $para );
	}
	if ( $items ) {
		$out .= veryo_b_list( $items, $style ? array( 'className' => 'is-style-' . $style ) : array() );
	}
	return $out;
}

/**
 * Catalogusitems als lijst met naam, uitleg en indicatie.
 *
 * @param string[] $ids   Catalogus-ID's.
 * @param string   $title Kop (H2).
 * @param string   $intro Inleiding.
 * @param int      $level Kopniveau.
 * @return string
 */
function veryo_sec_catalog( $ids, $title, $intro = '', $level = 2 ) {
	$levels = veryo_catalog_levels();
	$items  = array();
	foreach ( $ids as $id ) {
		$item = veryo_catalog_item( $id );
		if ( ! $item ) {
			continue;
		}
		$meta = sprintf(
			/* translators: 1: tijdwinst, 2: niveau. */
			__( 'Indicatie: %1$s · %2$s', 'veryo' ),
			$item['tijdwinst_tekst'],
			$levels[ $item['niveau'] ]['label']
		);
		$items[] = '<strong>' . esc_html( $item['naam'] ) . '</strong><br>' . esc_html( $item['wat'] ) . '<br><span class="veryo-meta">' . esc_html( $meta ) . '</span>';
	}
	$out = $title ? veryo_b_h( $title, $level ) : '';
	if ( $intro ) {
		$out .= veryo_b_p( $intro );
	}
	$out .= veryo_b_list( $items, array( 'className' => 'is-style-catalog' ) );
	return $out;
}

/**
 * De vier echte stappen: AI-scan, kansensessie, invoeren en bouwen, onderhoud.
 *
 * @param string $title Kop.
 * @param string $intro Optionele inleiding.
 * @return string
 */
function veryo_sec_steps( $title = '', $intro = '' ) {
	$title = $title ? $title : __( 'Zo werkt het', 'veryo' );
	$steps = array(
		'<strong>' . __( 'Gratis AI-scan', 'veryo' ) . '</strong><br>' . sprintf(
			/* translators: %s: link naar de AI-scan. */
			__( 'Je beantwoordt negen vragen over je bedrijf en krijgt een rapport met je drie grootste tijdwinsten. Duurt ongeveer drie minuten. <a href="%s">Start de AI-scan</a>.', 'veryo' ),
			esc_url( veryo_link( 'waar-begin-ik-met-ai' ) )
		),
		'<strong>' . __( 'Kansensessie', 'veryo' ) . '</strong><br>' . __( 'Samen lopen we je processen door en zetten we de kansen op volgorde: wat levert het meest op, wat is snel te doen, wat laten we liggen. We kijken ook welke software je al hebt en wat die kan. De kansensessie is onderdeel van het AI-Startpakket.', 'veryo' ),
		'<strong>' . __( 'Invoeren en bouwen', 'veryo' ) . '</strong><br>' . __( 'Eerst richten we software in die je al hebt of kunt nemen, en leren we je team ermee werken. Alleen waar dat tekortschiet, bouwen we een eigen koppeling, in je eigen accounts. Eerst een proefperiode met echte gegevens, dan pas live.', 'veryo' ),
		'<strong>' . __( 'Onderhoud', 'veryo' ) . '</strong><br>' . __( 'We houden alles in de gaten en passen aan als er iets verandert. Elke koppeling heeft een logboek en een vaste eigenaar. Wil je doorlopend een vraagbaak, dan is er het AI-partner-abonnement.', 'veryo' ),
	);
	$out   = veryo_b_h( $title );
	if ( $intro ) {
		$out .= veryo_b_p( $intro );
	}
	$out .= veryo_b_list(
		$steps,
		array(
			'ordered'   => true,
			'className' => 'is-style-steps',
		)
	);
	return veryo_b_group( $out, array( 'className' => 'veryo-steps' ) );
}

/**
 * "Wat kost het?": geen bedragen, wel de onderdelen en een knop naar de gratis offerte.
 *
 * @param string[] $steps Sleutels uit veryo_price_ladder().
 * @param string   $title Kop.
 * @param string   $intro Inleiding.
 * @return string
 */
function veryo_sec_price( $steps, $title = '', $intro = '' ) {
	$ladder = veryo_price_ladder();
	$items  = array();
	foreach ( $steps as $n ) {
		if ( ! isset( $ladder[ $n ] ) ) {
			continue;
		}
		$items[] = '<strong>' . esc_html( $ladder[ $n ]['dienst'] ) . '</strong>: ' . esc_html( $ladder[ $n ]['wat'] );
	}
	$title = $title ? $title : __( 'Wat kost het?', 'veryo' );
	$out   = veryo_b_h( $title );
	$out  .= veryo_b_p( __( 'Dat hangt af van je team, je software en wat je wilt aanpakken. Daarom krijg je een gratis offerte op maat, met vooraf een vaste prijs en zonder verplichtingen.', 'veryo' ) );
	if ( $intro ) {
		$out .= veryo_b_p( $intro );
	}
	if ( $items ) {
		$out .= veryo_b_list( $items, array( 'className' => 'is-style-checks' ) );
	}
	$out .= veryo_b_buttons( array( array( veryo_offerte_label(), veryo_offerte_url() ) ) );
	return veryo_b_group( $out, array( 'className' => 'is-style-soft veryo-price' ) );
}

/**
 * Overzicht als rustige tabel (homepage): dienst, wat het is en een link naar de offerte.
 * Alleen het AI-Startpakket krijgt het amber accent.
 *
 * @param string[] $keys Sleutels uit veryo_price_ladder().
 * @return string
 */
function veryo_sec_price_table( $keys ) {
	$ladder = veryo_price_ladder();
	$items  = array();
	foreach ( $keys as $key ) {
		if ( ! isset( $ladder[ $key ] ) ) {
			continue;
		}
		$row     = $ladder[ $key ];
		$text    = '<span class="t">' . esc_html( $row['dienst'] ) . '</span> <span class="d">' . esc_html( $row['wat'] ) . '</span> <span class="p">' . veryo_price_cell( $key ) . '</span>';
		$items[] = 'startpakket' === $key ? array(
			'class' => 'is-featured',
			'text'  => $text,
		) : $text;
	}
	return veryo_b_list( $items, array( 'className' => 'veryo-price-table' ) );
}

/**
 * Laatste kolom van een overzichtstabel: "Gratis" voor de AI-scan, anders een link naar de offerte.
 *
 * @param string $key Sleutel uit veryo_price_ladder().
 * @return string HTML.
 */
function veryo_price_cell( $key = '' ) {
	if ( 'scan' === $key ) {
		return esc_html__( 'Gratis', 'veryo' );
	}
	return '<a href="' . esc_url( veryo_offerte_url() ) . '">' . esc_html__( 'Gratis offerte', 'veryo' ) . '</a>';
}

/**
 * De volledige prijsladder (§7): scan, startpakket, invoering, partner. Plus losse onderdelen.
 * Het AI-Startpakket is de enige trede met een amber accent.
 *
 * @return string
 */
function veryo_sec_ladder() {
	$l     = veryo_price_ladder();
	$tag   = static function ( $row ) {
		return '<strong>' . esc_html( $row['dienst'] ) . '</strong>';
	};
	$items = array(
		$tag( $l['scan'] ) . ' <span class="veryo-price-tag">' . esc_html( $l['scan']['prijs'] ) . '</span><br>' . esc_html( $l['scan']['wat'] ) . '<br><span class="veryo-meta">' . esc_html( $l['scan']['voor'] ) . '</span>',
		array(
			'class' => 'is-featured',
			'text'  => '<span class="veryo-flag">' . esc_html__( 'Aanbevolen start', 'veryo' ) . '</span><br><strong>' . esc_html( $l['startpakket']['dienst'] ) . '</strong><br>' . esc_html( $l['startpakket']['wat'] ) . '<br><span class="veryo-meta">' . esc_html( $l['startpakket']['voor'] ) . ' <a href="' . esc_url( veryo_link( 'ai-startpakket' ) ) . '">' . esc_html__( 'Alles over het AI-Startpakket', 'veryo' ) . '</a></span>',
		),
		'<strong>' . esc_html__( 'Invoering en koppelingen', 'veryo' ) . '</strong><br>' . esc_html__( 'De beste kansen uit de kansensessie invoeren: eerst met software die je al hebt of kunt nemen, alleen waar nodig met een eigen koppeling of maatwerk. Van een afgebakende quick win tot een project of maatwerk.', 'veryo' ),
		'<strong>' . esc_html__( 'Doorlopend: abonnement of AI-partner', 'veryo' ) . '</strong><br>' . esc_html__( 'Bij elk pakket hoort één passend abonnement. Heb je er meerdere nodig, dan is AI-partner voordeliger.', 'veryo' ) . '<br><span class="veryo-meta">' . esc_html( $l['partner']['voor'] ) . ' ' . esc_html__( 'Gebouwde koppelingen en agents hebben altijd onderhoud nodig.', 'veryo' ) . '</span>',
	);
	$out   = veryo_b_list(
		$items,
		array(
			'ordered'   => true,
			'className' => 'is-style-ladder',
		)
	);
	$out  .= veryo_b_h( __( 'Losse onderdelen', 'veryo' ), 3 );
	$loose = array();
	foreach ( array( 'kansensessie', 'training', 'werkplek', 'veiligheidscheck', 'agents', 'academy' ) as $key ) {
		$loose[] = $tag( $l[ $key ] ) . '<br><span class="veryo-meta">' . esc_html( $l[ $key ]['wat'] ) . '</span>';
	}
	$out .= veryo_b_list( $loose, array( 'className' => 'is-style-prices' ) );
	$out .= veryo_b_buttons( array( array( veryo_offerte_label(), veryo_offerte_url() ) ) );
	return $out;
}

/**
 * Het AI-Startpakket als uitgelicht product (homepage en elders).
 *
 * @param string $title Kop.
 * @param string $intro Inleiding.
 * @return string
 */
function veryo_sec_startpakket( $title = '', $intro = '' ) {
	$title = $title ? $title : __( 'Het Veryo AI-Startpakket', 'veryo' );
	$intro = $intro ? $intro : __( 'Alles wat je nodig hebt om AI goed en veilig in je bedrijf te laten landen, in één pakket.', 'veryo' );
	$parts = array();
	foreach ( veryo_startpakket_parts() as $part ) {
		$parts[] = '<strong>' . esc_html( $part[0] ) . '</strong><br>' . esc_html( $part[1] );
	}
	$left   = veryo_b_h( $title, 2, array( 'fontSize' => 'display-l' ) ) . veryo_b_p( $intro, array( 'className' => 'veryo-lead' ) );
	$left  .= veryo_b_list( $parts, array( 'className' => 'is-style-parts' ) );
	$right  = veryo_b_h( __( 'Een offerte op maat van je team', 'veryo' ), 3 );
	$right .= veryo_b_p( __( 'Je krijgt vooraf een vaste prijs, afgestemd op de grootte van je team. Geen software, geen verplicht abonnement: je betaalt het pakket één keer.', 'veryo' ) );
	$right .= veryo_b_buttons(
		array(
			array( veryo_offerte_label(), veryo_offerte_url() ),
			array( __( 'Bekijk het AI-Startpakket', 'veryo' ), veryo_link( 'ai-startpakket' ), 'link' ),
		)
	);
	return veryo_b_group(
		veryo_b_columns(
			array(
				array(
					'width' => '60%',
					'inner' => $left,
				),
				array(
					'width' => '40%',
					'class' => 'veryo-featured__side',
					'inner' => $right,
				),
			)
		),
		array(
			'align'     => 'wide',
			'className' => 'is-style-paper veryo-featured',
			'layout'    => false,
		)
	);
}

/**
 * "Onafhankelijk advies": Veryo verkoopt geen eigen software.
 *
 * @param string $title Kop.
 * @param bool   $wide  Brede variant met statement (homepage).
 * @return string
 */
function veryo_sec_independent( $title = '', $wide = false ) {
	$title = $title ? $title : __( 'Onafhankelijk advies', 'veryo' );
	if ( $wide ) {
		$left  = veryo_b_h( $title ) . veryo_b_p( __( 'We verkopen geen software. Daardoor kunnen we eerlijk adviseren over welke tool bij jou past.', 'veryo' ), array( 'className' => 'veryo-statement' ) );
		$right = veryo_b_p( __( 'Steeds meer pakketten die je al gebruikt, krijgen AI ingebouwd: je mailprogramma, je boekhouding, je CRM. Daar zit vaak meer in dan je denkt. Wij zorgen dat je de juiste tool kiest, dat hij goed is ingericht en dat je team hem ook echt gebruikt.', 'veryo' ) )
			. veryo_b_p( __( 'Pas als bestaande software tekortschiet, bouwen we een koppeling of iets op maat. En worden we ooit partner van een softwareleverancier waar we een vergoeding voor krijgen, dan zeggen we dat erbij als we die software adviseren.', 'veryo' ) );
		return veryo_b_group(
			veryo_b_columns(
				array(
					array(
						'width' => '50%',
						'inner' => $left,
					),
					array(
						'width' => '50%',
						'inner' => $right,
					),
				)
			),
			array(
				'align'     => 'wide',
				'className' => 'is-style-soft veryo-independent veryo-section',
				'layout'    => false,
			)
		);
	}
	$inner = veryo_b_h( $title )
		. veryo_b_p( __( 'We verkopen geen eigen software. Steeds meer pakketten die je al gebruikt, krijgen AI ingebouwd: je mailprogramma, je boekhouding, je CRM. Daar zit vaak meer in dan je denkt. Wij zorgen dat je de juiste tool kiest, dat hij goed is ingericht en dat je team hem ook echt gebruikt.', 'veryo' ) )
		. veryo_b_p( __( 'Pas als bestaande software tekortschiet, bouwen we een koppeling of iets op maat. En worden we ooit partner van een softwareleverancier waar we een vergoeding voor krijgen, dan zeggen we dat erbij als we die software adviseren.', 'veryo' ) );
	return veryo_b_group( $inner, array( 'className' => 'is-style-soft veryo-independent' ) );
}

/**
 * Aanpak per proces: eerst wat je al hebt, dan pas bouwen.
 *
 * @param string $title Kop.
 * @return string
 */
function veryo_sec_approach( $title = '' ) {
	$title = $title ? $title : __( 'Onze aanpak: eerst wat je al hebt', 'veryo' );
	$items = array(
		'<strong>' . __( 'Kijken wat er al is.', 'veryo' ) . '</strong> ' . __( 'Veel software die je al gebruikt, heeft inmiddels AI-functies. Vaak lost dat een groot deel op.', 'veryo' ),
		'<strong>' . __( 'Inrichten en trainen.', 'veryo' ) . '</strong> ' . __( 'We zetten de juiste functies aan, of kiezen samen een passende tool, en leren je team ermee werken.', 'veryo' ),
		'<strong>' . __( 'Alleen bouwen waar nodig.', 'veryo' ) . '</strong> ' . __( 'Blijft er een gat, bijvoorbeeld tussen twee systemen die niet met elkaar praten, dan bouwen we een koppeling of automatisering.', 'veryo' ),
	);
	return veryo_b_group(
		veryo_b_h( $title ) . veryo_b_list(
			$items,
			array(
				'ordered'   => true,
				'className' => 'is-style-steps',
			)
		),
		array( 'className' => 'veryo-approach' )
	);
}

/**
 * FAQ-blok. Het schema (FAQPage) wordt uit dit blok gegenereerd.
 *
 * @param array<int,array<int,string>> $faqs  Lijst van array( vraag, antwoord ).
 * @param string|false                 $title Kop; false = zonder kop (die staat dan ernaast).
 * @return string
 */
function veryo_sec_faq( $faqs, $title = '' ) {
	if ( false === $title ) {
		$inner = '';
	} else {
		$inner = veryo_b_h( $title ? $title : __( 'Veelgestelde vragen', 'veryo' ) );
	}
	foreach ( $faqs as $faq ) {
		$inner .= veryo_b_details( $faq[0], $faq[1] );
	}
	return veryo_b_group( $inner, array( 'className' => 'veryo-faq' ) );
}

/**
 * CTA-blok voor de AI-scan, op petrol met groot vinkje.
 *
 * @param string $title Kop.
 * @param string $text  Tekst.
 * @return string
 */
function veryo_sec_cta_scan( $title = '', $text = '' ) {
	$title = $title ? $title : __( 'Benieuwd wat AI jouw bedrijf oplevert?', 'veryo' );
	$text  = $text ? $text : __( 'Doe de gratis AI-scan. Negen vragen, ongeveer drie minuten, en je krijgt een persoonlijk rapport met je drie grootste tijdwinsten. Je zit nergens aan vast.', 'veryo' );
	$inner = veryo_b_h( $title, 2, array( 'fontSize' => 'display-l' ) )
		. veryo_b_p( $text, array( 'className' => 'veryo-lead' ) )
		. veryo_b_buttons( array( array( __( 'Doe de gratis AI-scan', 'veryo' ), veryo_link( 'waar-begin-ik-met-ai' ), 'amber' ) ) );
	return veryo_b_group(
		$inner,
		array(
			'tagName'   => 'section',
			'align'     => 'full',
			'className' => 'is-style-petrol veryo-cta has-check',
		)
	);
}

/**
 * Link voor "plan een afspraak": de afspraaklink uit Instellingen > Veryo, anders Calendly.
 *
 * @return string
 */
function veryo_afspraak_url() {
	$url = (string) veryo_setting( 'calendly_url', '' );
	return '' !== $url ? $url : ( defined( 'VERYO_LP_CALENDLY_URL' ) ? VERYO_LP_CALENDLY_URL : veryo_link( 'contact' ) );
}

/**
 * Afsluitend CTA-blok met een afspraak (demo of kennismaking) in plaats van de AI-scan.
 *
 * @param string $title Kop.
 * @param string $text  Tekst.
 * @return string
 */
function veryo_sec_cta_demo( $title, $text = '' ) {
	$inner = veryo_b_h( $title, 2, array( 'fontSize' => 'display-l' ) );
	if ( $text ) {
		$inner .= veryo_b_p( $text, array( 'className' => 'veryo-lead' ) );
	}
	$inner .= veryo_b_buttons(
		array(
			array( $title, veryo_afspraak_url(), 'amber' ),
			array( __( 'Of stuur een vraag', 'veryo' ), veryo_link( 'contact' ), 'link' ),
		)
	);
	return veryo_b_group(
		$inner,
		array(
			'tagName'   => 'section',
			'align'     => 'full',
			'className' => 'is-style-petrol veryo-cta has-check',
		)
	);
}

/**
 * Shortcode [veryo_bloglink slug="..." tekst="..."]: een link naar een blogbericht, maar alleen als
 * dat bericht gepubliceerd is. Anders staat er gewone tekst, zodat er geen link naar een concept is.
 *
 * @param array<string,string>|string $atts Attributen.
 * @return string
 */
function veryo_sc_bloglink( $atts ) {
	$atts = shortcode_atts(
		array(
			'slug'  => '',
			'tekst' => '',
		),
		$atts,
		'veryo_bloglink'
	);
	$post = '' !== $atts['slug'] ? get_page_by_path( sanitize_title( $atts['slug'] ), OBJECT, 'post' ) : null;
	if ( $post instanceof WP_Post && 'publish' === $post->post_status ) {
		return '<a href="' . esc_url( get_permalink( $post ) ) . '">' . esc_html( $atts['tekst'] ) . '</a>';
	}
	return esc_html( $atts['tekst'] );
}
add_shortcode( 'veryo_bloglink', 'veryo_sc_bloglink' );

/**
 * Overzicht van alle branches met links.
 *
 * @param string $title Kop.
 * @param string $intro Inleiding.
 * @param bool   $wide  Brede variant (homepage).
 * @return string
 */
function veryo_sec_branches( $title = '', $intro = '', $wide = false ) {
	$branches = array(
		'installatie'               => array( __( 'Installatietechniek', 'veryo' ), __( 'Offertes, werkbonnen en storingen', 'veryo' ) ),
		'bouw'                      => array( __( 'Bouw en aannemerij', 'veryo' ), __( 'Materiaalstaten, nacalculatie en meerwerk', 'veryo' ) ),
		'agri'                      => array( __( 'Agri en mechanisatie', 'veryo' ), __( 'Onderhoud, keuringen en onderdelen', 'veryo' ) ),
		'makelaardij'               => array( __( 'Makelaardij', 'veryo' ), __( 'Inbox, bezichtigingen en woningteksten', 'veryo' ) ),
		'zakelijke-dienstverlening' => array( __( 'Accountants en adviesbureaus', 'veryo' ), __( 'Verslagen, samenvattingen en kennis', 'veryo' ) ),
		'horeca-retail'             => array( __( 'Horeca en retail', 'veryo' ), __( 'Reviews, social en reserveringen', 'veryo' ) ),
		'transport'                 => array( __( 'Transport en logistiek', 'veryo' ), __( 'Planning, statusberichten en documenten', 'veryo' ) ),
		'recruitment'               => array( __( 'Werving en recruitment', 'veryo' ), __( 'Solliciteren via WhatsApp', 'veryo' ) ),
		'beveiliging'               => array( __( 'Beveiligingsbedrijven', 'veryo' ), __( 'Urencontrole, rapportages en roosters', 'veryo' ) ),
		'schoonmaak'                => array( __( 'Schoonmaakbedrijven', 'veryo' ), __( 'Uren, roosters en inkoopfacturen', 'veryo' ) ),
	);
	$items    = array();
	foreach ( $branches as $slug => $b ) {
		$items[] = '<a href="' . esc_url( veryo_link( 'branches/' . $slug ) ) . '">' . esc_html( $b[0] ) . '</a><br><span class="veryo-meta">' . esc_html( $b[1] ) . '</span>';
	}
	$title = $title ? $title : __( 'AI per branche', 'veryo' );
	if ( $wide ) {
		$out = veryo_sec_head( $title, $intro ? veryo_b_p( $intro ) : '' ) . veryo_b_list( $items, array( 'className' => 'is-style-grid' ) );
		return veryo_sec_wide( $out, 'veryo-branches' );
	}
	$out = veryo_b_h( $title );
	if ( $intro ) {
		$out .= veryo_b_p( $intro );
	}
	$out .= veryo_b_list( $items, array( 'className' => 'is-style-grid' ) );
	return veryo_b_group( $out, array( 'className' => 'veryo-branches' ) );
}

/**
 * Regioblok: Friesland, Groningen, Drenthe en Leeuwarden.
 *
 * @param string $title Kop.
 * @param string $intro Inleiding.
 * @param bool   $wide  Brede variant (homepage).
 * @return string
 */
function veryo_sec_regions( $title = '', $intro = '', $wide = false ) {
	$title = $title ? $title : __( 'Uit Leeuwarden, voor heel Noord-Nederland', 'veryo' );
	$intro = $intro ? $intro : __( 'Veryo zit in Leeuwarden. In Friesland, Groningen en Drenthe komen we gewoon langs: aan de keukentafel, in de werkplaats of op kantoor. Trainingen en online diensten doen we ook in de rest van Nederland.', 'veryo' );
	$items = array(
		'<a href="' . esc_url( veryo_link( 'ai-adviseur-friesland' ) ) . '">' . __( 'AI-adviseur in Friesland', 'veryo' ) . '</a><br><span class="veryo-meta">' . __( 'Leeuwarden, Heerenveen, Sneek, Drachten, Harlingen, Dokkum', 'veryo' ) . '</span>',
		'<a href="' . esc_url( veryo_link( 'ai-adviseur-groningen' ) ) . '">' . __( 'AI-adviseur in Groningen', 'veryo' ) . '</a><br><span class="veryo-meta">' . __( 'Stad Groningen, Veendam, Hoogezand, Delfzijl, Winsum', 'veryo' ) . '</span>',
		'<a href="' . esc_url( veryo_link( 'ai-adviseur-drenthe' ) ) . '">' . __( 'AI-adviseur in Drenthe', 'veryo' ) . '</a><br><span class="veryo-meta">' . __( 'Assen, Emmen, Hoogeveen, Meppel', 'veryo' ) . '</span>',
		'<a href="' . esc_url( veryo_link( 'leeuwarden' ) ) . '">' . __( 'AI-training en automatisering in Leeuwarden', 'veryo' ) . '</a><br><span class="veryo-meta">' . __( 'Onze thuisbasis', 'veryo' ) . '</span>',
	);
	$inner = veryo_b_columns(
		array(
			array(
				'width' => '42%',
				'inner' => veryo_b_h( $title ) . veryo_b_p( $intro ),
			),
			array(
				'width' => '58%',
				'inner' => veryo_b_list( $items, array( 'className' => 'is-style-regions' ) ),
			),
		)
	);
	if ( $wide ) {
		return veryo_sec_wide( $inner, 'veryo-regions' );
	}
	return veryo_b_group( $inner, array( 'className' => 'veryo-regions' ) );
}

/**
 * Interne links naar gerelateerde pagina's.
 *
 * @param array<int,array<int,string>> $links Lijst van array( pad, linktekst, korte uitleg ).
 * @param string                       $title Kop.
 * @return string
 */
function veryo_sec_links( $links, $title = '' ) {
	$items = array();
	foreach ( $links as $link ) {
		$items[] = '<a href="' . esc_url( veryo_link( $link[0] ) ) . '">' . esc_html( $link[1] ) . '</a>' . ( ! empty( $link[2] ) ? '<br><span class="veryo-meta">' . esc_html( $link[2] ) . '</span>' : '' );
	}
	$out = veryo_b_h( $title ? $title : __( 'Verder lezen', 'veryo' ) ) . veryo_b_list( $items, array( 'className' => 'is-style-related' ) );
	return veryo_b_group( $out, array( 'className' => 'veryo-related' ) );
}

/**
 * Cases en reviews. Verborgen zolang "Toon cases" uit staat (zie veryo_hide_cases_block).
 *
 * @return string
 */
function veryo_sec_cases() {
	$inner  = veryo_b_h( __( 'Wat klanten zeggen', 'veryo' ) );
	$inner .= veryo_b_p( __( '[VUL IN: echte klantcase, met toestemming van de klant: branche, uitgangssituatie, wat we hebben gebouwd en het gemeten resultaat]', 'veryo' ) );
	$inner .= veryo_b_p( __( '[VUL IN: echte review met naam, functie en bedrijf, alleen met toestemming]', 'veryo' ) );
	return veryo_b_group( $inner, array( 'className' => 'veryo-cases is-style-paper' ) );
}

/**
 * Wat we doen, in vier delen, bewust in verschillende vormen (geen identieke kaarten).
 *
 * @return string
 */
function veryo_sec_services() {
	$advies  = veryo_b_h( __( 'Advies', 'veryo' ), 3, array( 'fontSize' => 'display-m' ) );
	$advies .= veryo_b_p( __( 'We zoeken uit waar AI in jouw bedrijf het meeste oplevert en welke tools daarbij passen. Vaak is dat software die je al hebt. Je krijgt een plan met prioriteiten, niet een stapel mogelijkheden.', 'veryo' ) );
	$advies .= veryo_b_list(
		array(
			__( 'Kansensessie met roadmap', 'veryo' ),
			__( 'Onafhankelijk advies over tools', 'veryo' ),
			__( 'AI-beleid op maat', 'veryo' ),
		),
		array( 'className' => 'is-style-checks' )
	);
	$advies .= veryo_b_buttons( array( array( __( 'Over AI-implementatie', 'veryo' ), veryo_link( 'ai-implementatie-mkb' ), 'link' ) ) );

	$training  = veryo_b_h( __( 'Training', 'veryo' ), 3 );
	$training .= veryo_b_p( __( 'Een halve of hele dag met je eigen team. Praktisch, met voorbeelden uit jullie werk, en je werkt meteen aan de AI-geletterdheid die de AI Act vraagt.', 'veryo' ) );
	$training .= veryo_b_buttons( array( array( __( 'Over de training', 'veryo' ), veryo_link( 'ai-training' ), 'link' ) ) );

	$invoering  = veryo_b_h( __( 'Invoering en koppelingen', 'veryo' ), 3 );
	$invoering .= veryo_b_p( __( 'We richten de gekozen tools in en koppelen systemen die niet met elkaar praten. Alleen waar bestaande software tekortschiet, bouwen we iets op maat.', 'veryo' ) );
	$invoering .= veryo_b_buttons( array( array( __( 'Wat er mogelijk is', 'veryo' ), veryo_link( 'ai-automatisering' ), 'link' ) ) );

	$partner = veryo_b_columns(
		array(
			array(
				'width' => '30%',
				'inner' => veryo_b_h( __( 'Partner', 'veryo' ), 3 ),
			),
			array(
				'width' => '70%',
				'inner' => veryo_b_p( __( 'Een vaste vraagbaak voor alles rond AI: maandelijks overleg, nieuwe medewerkers bijscholen en kleine verbeteringen. Zodat het niet stilvalt na de eerste maand.', 'veryo' ) )
					. veryo_b_buttons( array( array( __( 'Over het AI-partner-abonnement', 'veryo' ), veryo_link( 'ai-partner' ), 'link' ) ) ),
			),
		),
		array( 'className' => 'veryo-partner-row' )
	);

	$inner  = veryo_sec_head( __( 'Wat we doen', 'veryo' ), veryo_b_p( __( 'Van het eerste advies tot een vaste vraagbaak. Je kunt bij elke stap instappen, en we doen alleen wat zichtbaar tijd of geld oplevert.', 'veryo' ) ) );
	$inner .= veryo_b_columns(
		array(
			array(
				'width' => '58%',
				'class' => 'veryo-service-main',
				'inner' => $advies,
			),
			array(
				'width' => '42%',
				'class' => 'veryo-service-side',
				'inner' => veryo_b_group( $training, array( 'className' => 'veryo-service-plain' ) ) . veryo_b_group( $invoering, array( 'className' => 'veryo-service-plain' ) ),
			),
		)
	);
	$inner .= $partner;
	return veryo_b_group(
		$inner,
		array(
			'align'     => 'wide',
			'className' => 'veryo-services veryo-section',
			'anchor'    => 'wat-we-doen',
			'layout'    => false,
		)
	);
}

/**
 * Stappen op de homepage: AI-scan, AI-Startpakket, invoering, AI-partner.
 *
 * @return string
 */
function veryo_sec_steps_home() {
	$steps = array(
		'<strong>' . __( 'Gratis AI-scan', 'veryo' ) . '</strong><br>' . __( 'Negen vragen, drie minuten, en je weet waar de tijdwinst zit.', 'veryo' ),
		'<strong>' . __( 'AI-Startpakket', 'veryo' ) . '</strong><br>' . __( 'Kansensessie, teamtraining, AI-beleid, één quick win ingericht en 30 dagen nazorg.', 'veryo' ),
		'<strong>' . __( 'Invoering van de beste kansen', 'veryo' ) . '</strong><br>' . __( 'Eerst met software die je al hebt, alleen waar nodig met een eigen koppeling.', 'veryo' ),
		'<strong>' . __( 'AI-partner', 'veryo' ) . '</strong><br>' . __( 'Een vaste vraagbaak die zorgt dat het blijft werken en beter wordt.', 'veryo' ),
	);
	return veryo_b_group(
		veryo_sec_head( __( 'Zo werken we', 'veryo' ), veryo_b_p( __( 'Vier stappen, van eerste vraag tot een team dat er elke dag mee werkt. Je kunt na elke stap stoppen.', 'veryo' ) ) )
		. veryo_b_list(
			$steps,
			array(
				'ordered'   => true,
				'className' => 'is-style-steps',
			)
		),
		array(
			'align'     => 'wide',
			'className' => 'veryo-steps veryo-steps--home veryo-section',
			'layout'    => false,
		)
	);
}

/**
 * Standaardopbouw voor dienst-, regio- en branchepagina's (§5).
 *
 * @param array<string,mixed> $d Pagina-onderdelen.
 * @return string
 */
function veryo_page_standard( $d ) {
	$out = veryo_sec_answer( $d['answer'] );

	if ( ! empty( $d['problem'] ) ) {
		$out .= veryo_sec_text( $d['problem']['h'], $d['problem']['p'], isset( $d['problem']['list'] ) ? $d['problem']['list'] : array() );
	}
	if ( ! empty( $d['help'] ) ) {
		$out .= veryo_sec_text(
			$d['help'][0],
			array(),
			array(
				'<strong><a href="' . esc_url( veryo_collega_url() ) . '">' . esc_html__( 'Veryo Collega, lokale AI-assistent', 'veryo' ) . '</a>.</strong> ' . $d['help'][1],
				'<strong><a href="' . esc_url( veryo_link( 'ai-training' ) ) . '">' . esc_html__( 'AI-training en workshops', 'veryo' ) . '</a>.</strong> ' . $d['help'][2],
				'<strong><a href="' . esc_url( veryo_link( 'ai-automatisering' ) ) . '">' . esc_html__( 'Automatisering', 'veryo' ) . '</a>.</strong> ' . $d['help'][3],
			),
			'checks'
		);
	}
	if ( ! empty( $d['photo'] ) ) {
		$out .= veryo_sec_photo( $d['photo'][0], $d['photo'][1], isset( $d['photo'][2] ) ? $d['photo'][2] : '' );
	}
	if ( ! empty( $d['approach'] ) ) {
		$out .= veryo_sec_approach();
	}
	if ( ! empty( $d['products'] ) ) {
		$out .= veryo_sec_products( $d['products']['keys'], $d['products']['h'], isset( $d['products']['intro'] ) ? $d['products']['intro'] : '', true, $d['products']['keys'][0] );
	}
	if ( ! empty( $d['solutions'] ) ) {
		$links = array();
		foreach ( veryo_products() as $key => $product ) {
			$links[] = array( 'oplossingen/' . $key, $product['naam'], $product['voor'] );
		}
		$out .= veryo_sec_links( $links, __( 'Concreet: onze oplossingen', 'veryo' ) );
	}
	if ( ! empty( $d['catalog'] ) ) {
		$out .= veryo_sec_catalog( $d['catalog']['ids'], $d['catalog']['h'], isset( $d['catalog']['intro'] ) ? $d['catalog']['intro'] : '' );
	}
	if ( ! empty( $d['sections'] ) ) {
		foreach ( $d['sections'] as $section ) {
			$out .= veryo_sec_text(
				$section['h'],
				isset( $section['p'] ) ? $section['p'] : array(),
				isset( $section['list'] ) ? $section['list'] : array(),
				isset( $section['style'] ) ? $section['style'] : ''
			);
		}
	}
	if ( ! empty( $d['extra'] ) ) {
		$out .= veryo_sec_text( $d['extra'][0], $d['extra'][1] );
	}
	if ( empty( $d['no_steps'] ) ) {
		$out .= veryo_sec_steps( isset( $d['steps_title'] ) ? $d['steps_title'] : '', isset( $d['steps_intro'] ) ? $d['steps_intro'] : '' );
	}
	if ( ! empty( $d['price'] ) ) {
		$out .= veryo_sec_price( $d['price']['steps'], isset( $d['price']['h'] ) ? $d['price']['h'] : '', isset( $d['price']['p'] ) ? $d['price']['p'] : '' );
	}
	if ( ! empty( $d['after_price'] ) ) {
		$out .= $d['after_price'];
	}
	if ( empty( $d['no_collega'] ) ) {
		if ( ! empty( $d['collega_regio'] ) ) {
			$out .= veryo_sec_collega_blok( 'regio', $d['collega_regio'] );
		} else {
			$out .= veryo_sec_collega_blok( isset( $d['collega_variant'] ) ? $d['collega_variant'] : 'standaard' );
		}
	}
	if ( empty( $d['no_contact'] ) ) {
		$contact = isset( $d['contact'] ) ? $d['contact'] : array();
		$out    .= veryo_sec_contact(
			isset( $contact[0] ) ? $contact[0] : '',
			isset( $contact[1] ) ? $contact[1] : '',
			isset( $contact[2] ) ? $contact[2] : ''
		);
	}
	if ( ! empty( $d['faq'] ) ) {
		$out .= veryo_sec_faq( $d['faq'] );
	}
	$cta  = isset( $d['cta'] ) ? $d['cta'] : array( '', '' );
	$out .= ! empty( $d['cta_demo'] ) ? veryo_sec_cta_demo( $cta[0], $cta[1] ) : veryo_sec_cta_scan( $cta[0], $cta[1] );
	if ( ! empty( $d['links'] ) ) {
		$out .= veryo_sec_links( $d['links'] );
	}
	return $out;
}

/**
 * Contactblok met kort formulier: wie twijfelt, stelt direct een vraag aan de oprichter.
 * Op tactische plekken: na de prijs, voor de veelgestelde vragen.
 *
 * @param string $title       Kop.
 * @param string $text        Inleiding.
 * @param string $placeholder Voorbeeldvraag in het berichtveld.
 * @param string $anchor      Anker van de sectie.
 * @param string $button      Tekst op de knop.
 * @return string
 */
function veryo_sec_contact( $title = '', $text = '', $placeholder = '', $anchor = 'vraag', $button = '' ) {
	$title = $title ? $title : __( 'Twijfel je wat bij jou past? Vraag het gewoon.', 'veryo' );
	$text  = $text ? $text : __( 'Stel je vraag hier. Je krijgt binnen één werkdag een persoonlijk antwoord, zonder verkooppraatje en zonder dat je ergens aan vastzit.', 'veryo' );
	$name  = veryo_setting( 'founder_first' );
	$name  = $name ? $name : 'Veryo';
	$phone = veryo_setting( 'phone' );
	$email = veryo_setting( 'email' );
	$reach = array();
	if ( $phone ) {
		$reach[] = '<a href="' . esc_attr( veryo_tel_href( $phone ) ) . '">' . str_replace( ' ', '&nbsp;', esc_html( $phone ) ) . '</a>';
	}
	if ( $email ) {
		$reach[] = '<a href="mailto:' . esc_attr( $email ) . '">' . esc_html( $email ) . '</a>';
	}
	$left = veryo_b_p( esc_html__( 'Direct contact', 'veryo' ), array( 'className' => 'veryo-kicker' ) )
		. veryo_b_h( esc_html( $title ) )
		. veryo_b_p( esc_html( $text ), array( 'className' => 'veryo-lead' ) )
		. veryo_b_group(
			veryo_b_shortcode( '[veryo_portret size="small"]' )
			. veryo_b_p(
				'<strong>' . esc_html( $name ) . '</strong><br>'
				. esc_html__( 'Leest en beantwoordt je vraag zelf.', 'veryo' )
			),
			array(
				'className' => 'veryo-contact-band__person',
				'layout'    => false,
			)
		);
	if ( $reach ) {
		/* translators: %s: telefoonnummer en/of e-mailadres. */
		$left .= veryo_b_p( sprintf( esc_html__( 'Liever bellen of mailen? %s', 'veryo' ), implode( ' · ', $reach ) ), array( 'className' => 'veryo-small' ) );
	}
	$form = '[veryo_form type="contact" compact="1" button="' . str_replace( '"', '', $button ? $button : __( 'Stel je vraag', 'veryo' ) ) . '"' . ( $placeholder ? ' placeholder="' . str_replace( array( '"', '[', ']' ), '', $placeholder ) . '"' : '' ) . ']';
	return veryo_sec_wide(
		veryo_b_columns(
			array(
				array(
					'width' => '42%',
					'inner' => $left,
				),
				array(
					'width' => '58%',
					'inner' => veryo_b_group( veryo_b_shortcode( $form ), array( 'className' => 'is-style-paper veryo-form-wrap' ) ),
				),
			)
		),
		'veryo-contact-band',
		$anchor
	);
}

/**
 * "Daarna doorlopend": het abonnement dat bij een pakket hoort, direct onder de pakketprijs.
 *
 * @param string $key Sleutel uit veryo_subscriptions().
 * @return string
 */
function veryo_sec_ongoing( $key ) {
	$subs = veryo_subscriptions();
	if ( ! isset( $subs[ $key ] ) ) {
		return '';
	}
	$sub   = $subs[ $key ];
	$inner = veryo_b_h(
		/* translators: %s: naam abonnement. */
		sprintf( __( 'Daarna doorlopend: %s', 'veryo' ), $sub['naam'] ),
		3
	);
	$inner .= veryo_b_p( esc_html( $sub['inhoud'] ) );
	$inner .= veryo_b_p( esc_html__( 'De eerste maand loopt kosteloos mee; je kiest vooraf zelf of het daarna doorloopt.', 'veryo' ) );
	if ( 'onderhoud' !== $key ) {
		$inner .= veryo_b_p(
			sprintf(
				/* translators: %s: link naar AI-partner. */
				__( 'Meerdere abonnementen nodig? <a href="%s">AI-partner is voordeliger</a>.', 'veryo' ),
				esc_url( veryo_link( 'ai-partner' ) )
			),
			array( 'className' => 'veryo-small' )
		);
	}
	return veryo_b_group( $inner, array( 'className' => 'veryo-ongoing' ) );
}

/**
 * Tabel met de vier abonnementen.
 *
 * @return string
 */
function veryo_sec_subscriptions() {
	$items = array();
	foreach ( veryo_subscriptions() as $sub ) {
		$items[] = '<span class="t">' . esc_html( $sub['naam'] ) . '<br><span class="veryo-meta">' . esc_html(
			/* translators: %s: pakket. */
			sprintf( __( 'Bij: %s', 'veryo' ), $sub['bij'] )
		) . '</span></span> <span class="d">' . esc_html( $sub['inhoud'] ) . '</span> <span class="p">' . veryo_price_cell() . '</span>';
	}
	return veryo_b_list( $items, array( 'className' => 'veryo-price-table veryo-price-table--subs' ) );
}

/**
 * AI-partner per teamgrootte, met de rekenvergelijking.
 *
 * @param bool $comparison Rekenvergelijking tonen.
 * @return string
 */
function veryo_sec_partner_tiers( $comparison = true ) {
	$items = array();
	foreach ( veryo_partner_tiers() as $tier ) {
		$items[] = '<span class="t">' . esc_html( $tier['label'] ) . '</span> <span class="d">' . esc_html( $tier['extra'] ) . '</span> <span class="p">' . veryo_price_cell() . '</span>';
	}
	$out = veryo_b_list( $items, array( 'className' => 'veryo-price-table veryo-price-table--partner' ) );
	if ( $comparison ) {
		$out .= veryo_b_p( esc_html__( 'Neem je meerdere abonnementen af, dan is AI-partner voordeliger dan ze los te nemen, en krijg je er uren voor verbeteringen bij.', 'veryo' ), array( 'className' => 'veryo-comparison' ) );
	}
	$out .= veryo_b_p( esc_html__( 'Onderhoud van gebouwde koppelingen en agents valt niet onder AI-partner en blijft apart.', 'veryo' ), array( 'className' => 'veryo-small' ) );
	return $out;
}

/**
 * Voorwaarden voor abonnementen.
 *
 * @return string
 */
function veryo_sec_subscription_terms() {
	return veryo_sec_text(
		__( 'Zo werken de abonnementen', 'veryo' ),
		array(),
		array(
			__( 'Bij elk afgerond pakket loopt het passende abonnement de eerste maand kosteloos mee. Je kiest vooraf zelf of het daarna doorloopt; we verlengen nooit stilzwijgend.', 'veryo' ),
			__( 'Losse abonnementen hebben een minimale looptijd van drie maanden en zijn daarna maandelijks opzegbaar, met een opzegtermijn van één maand.', 'veryo' ),
			__( 'AI-partner sluit je af per jaar. Betaal je het jaar vooruit, dan krijg je korting; vraag ernaar bij je offerte.', 'veryo' ),
			__( 'Uren in AI-partner die je in een maand niet gebruikt, vervallen aan het eind van die maand.', 'veryo' ),
			__( 'Abonnementen worden maandelijks gefactureerd.', 'veryo' ),
		),
		'checks'
	);
}

/**
 * Blok "wat kost het" voor een pakket: geen bedragen, wel een knop naar de gratis offerte.
 *
 * @param string $title    Kop.
 * @param string $intro    Inleiding.
 * @param mixed  $rows     Niet meer gebruikt (vroeger de prijzen per teamgrootte).
 * @param string $note     Kleine tekst onder de knop.
 * @param bool   $featured Amber accent (alleen het AI-Startpakket).
 * @return string
 */
function veryo_sec_tiered_price( $title, $intro, $rows = array(), $note = '', $featured = false ) {
	unset( $rows );
	$inner = veryo_b_h( $title );
	if ( $intro ) {
		$inner .= veryo_b_p( $intro );
	}
	$inner .= veryo_b_p( esc_html__( 'Je krijgt een gratis offerte op maat, met vooraf een vaste prijs en zonder verplichtingen.', 'veryo' ) );
	$inner .= veryo_b_buttons( array( array( veryo_offerte_label(), veryo_offerte_url() ) ) );
	if ( $note ) {
		$inner .= veryo_b_p( $note, array( 'className' => 'veryo-small' ) );
	}
	return veryo_b_group( $inner, array( 'className' => 'is-style-soft veryo-price' . ( $featured ? ' is-featured' : '' ) ) );
}

/**
 * Founder-rij: portret van de oprichter met een korte regel. De foto komt uit
 * Instellingen > Veryo; zonder foto toont de shortcode een rustig monogram.
 *
 * @return string
 */
function veryo_sec_founder_row() {
	$name = trim( veryo_setting( 'founder_first' ) . ' ' . veryo_setting( 'founder_last' ) );
	$name = '' === $name ? __( 'De oprichter', 'veryo' ) : $name;
	return veryo_b_group(
		veryo_b_shortcode( '[veryo_portret size="small"]' )
		. veryo_b_p(
			'<strong>' . esc_html__( 'Uit Leeuwarden. Ik help je zelf, van scan tot partner.', 'veryo' ) . '</strong><br>'
			/* translators: %s: naam oprichter. */
			. esc_html( sprintf( __( '%s, oprichter van Veryo', 'veryo' ), $name ) )
		),
		array(
			'className' => 'veryo-founder',
			'layout'    => false,
		)
	);
}

/**
 * Doorlopende band met processen die Veryo aanpakt. Zonder JavaScript een gewone lijst.
 *
 * @return string
 */
function veryo_sec_marquee() {
	$items = array(
		__( 'Offertes', 'veryo' ),
		__( 'Facturen', 'veryo' ),
		__( 'Planning', 'veryo' ),
		__( 'Klantvragen', 'veryo' ),
		__( 'Werkbonnen', 'veryo' ),
		__( 'Werving', 'veryo' ),
		__( 'Rapportages', 'veryo' ),
		__( 'Copilot', 'veryo' ),
		__( 'Gemini', 'veryo' ),
		__( 'AI-beleid', 'veryo' ),
		__( 'Inkoop', 'veryo' ),
		__( 'Gespreksverslagen', 'veryo' ),
		__( 'WhatsApp', 'veryo' ),
		__( 'Onboarding', 'veryo' ),
	);
	return veryo_b_group(
		veryo_b_list( $items, array( 'className' => 'veryo-marquee__list' ) ),
		array(
			'align'     => 'full',
			'className' => 'veryo-marquee',
			'layout'    => false,
		)
	);
}

/**
 * Signatuursectie: zonder aanpak tegenover met Veryo.
 *
 * @return string
 */
function veryo_sec_contrast() {
	$pains  = array(
		__( 'Werk dat elke week opnieuw met de hand gaat.', 'veryo' ),
		__( 'Medewerkers die op eigen houtje ChatGPT gebruiken.', 'veryo' ),
		__( 'Software die je betaalt, maar half gebruikt.', 'veryo' ),
		__( 'Geen overzicht van wat AI oplevert.', 'veryo' ),
	);
	$gains  = array(
		__( 'Terugkerend werk loopt vanzelf, een mens controleert.', 'veryo' ),
		__( 'Duidelijke afspraken en zakelijke tools die iedereen kent.', 'veryo' ),
		__( 'Software die goed is ingericht en echt wordt gebruikt.', 'veryo' ),
		__( 'Een plan op volgorde van opbrengst, in uren en euro’s.', 'veryo' ),
	);
	$inner  = veryo_sec_head( __( 'Van losse pogingen naar een aanpak die werkt', 'veryo' ), veryo_b_p( __( 'Zo ziet AI er in veel bedrijven nu uit, en zo kan het eruitzien.', 'veryo' ) ) );
	$inner .= veryo_b_columns(
		array(
			array(
				'class' => 'veryo-contrast__without',
				'inner' => veryo_b_h( __( 'Zonder aanpak', 'veryo' ), 3 ) . veryo_b_list( $pains, array( 'className' => 'veryo-pains' ) ),
			),
			array(
				'class' => 'veryo-contrast__with',
				'inner' => veryo_b_h( __( 'Met Veryo', 'veryo' ), 3 ) . veryo_b_list( $gains, array( 'className' => 'veryo-gains' ) ),
			),
		),
		array( 'className' => 'veryo-contrast__cols' )
	);
	return veryo_sec_wide( $inner, 'veryo-contrast' );
}

/**
 * De zes pijlers. Bewust twee grotere panelen en vier kleinere.
 *
 * @return string
 */
function veryo_sec_pillars() {
	$pillars = array(
		array( 'ai-startpakket', __( 'Advies en AI-Startpakket', 'veryo' ), __( 'Gratis AI-scan, kansensessie en het AI-Startpakket: zo zet je AI in één keer goed neer.', 'veryo' ), true, __( 'Bekijk het AI-Startpakket', 'veryo' ) ),
		array( 'ai-werkplek', __( 'De AI-werkplek', 'veryo' ), __( 'Copilot of Gemini goed ingericht: licenties, rechten, instellingen en een team dat het gebruikt.', 'veryo' ), true, __( 'Meer over de AI-werkplek', 'veryo' ) ),
		array( 'ai-training', __( 'Training', 'veryo' ), __( 'In-company, AI-geletterdheid en straks de online Academy.', 'veryo' ), false, __( 'Meer over AI-training', 'veryo' ) ),
		array( 'ai-agents', __( 'Digitale collega’s', 'veryo' ), __( 'AI-agents, automatisering en koppelingen waar bestaande software tekortschiet.', 'veryo' ), false, __( 'Meer over AI-agents', 'veryo' ) ),
		array( 'veilig-ai-gebruik', __( 'Veilig AI-gebruik', 'veryo' ), __( 'Beleid, toegangsrechten, tweestapsverificatie en bewustwording.', 'veryo' ), false, __( 'Meer over veilig AI-gebruik', 'veryo' ) ),
		array( 'ai-partner', __( 'AI-partner', 'veryo' ), __( 'Doorlopende begeleiding in één abonnement, met uren voor verbeteringen.', 'veryo' ), false, __( 'Meer over AI-partner', 'veryo' ) ),
	);
	$panels  = '';
	foreach ( $pillars as $p ) {
		$panels .= veryo_b_group(
			veryo_b_h( esc_html( $p[1] ), 3 )
			. veryo_b_p( esc_html( $p[2] ) )
			. veryo_b_buttons(
				array(
					array( esc_html( $p[4] ), veryo_link( $p[0] ), 'link' ),
				)
			),
			array(
				'className' => 'veryo-pillar' . ( $p[3] ? ' is-large' : '' ),
				'layout'    => false,
			)
		);
	}
	$inner  = veryo_sec_head( __( 'Wat we doen, in zes pijlers', 'veryo' ), veryo_b_p( __( 'Van het eerste advies tot doorlopende begeleiding. Je kunt bij elke pijler instappen. Veryo is geen IT-bedrijf: algemeen beheer en helpdesk laten we aan je IT-beheerder.', 'veryo' ) ) );
	$inner .= veryo_b_group(
		$panels,
		array(
			'className' => 'veryo-pillars__track',
			'layout'    => false,
		)
	);
	return veryo_sec_wide( $inner, 'veryo-pillars', 'wat-we-doen' );
}

/**
 * Overtuiging van de oprichter, met portret.
 *
 * @return string
 */
function veryo_sec_conviction() {
	$name = trim( veryo_setting( 'founder_first' ) . ' ' . veryo_setting( 'founder_last' ) );
	$name = '' === $name ? __( 'De oprichter', 'veryo' ) : $name;
	return veryo_sec_wide(
		veryo_b_columns(
			array(
				array(
					'width' => '62%',
					'inner' => veryo_b_p( esc_html__( 'Ik ben Veryo begonnen omdat ik geloof dat AI bedrijven echt verder helpt. Niet met grote beloftes, maar door processen makkelijker te maken en tijd terug te geven die je liever aan je vak besteedt.', 'veryo' ), array( 'className' => 'veryo-quote' ) )
						/* translators: %s: naam oprichter. */
						. veryo_b_p( esc_html( sprintf( __( '%s, oprichter van Veryo', 'veryo' ), $name ) ), array( 'className' => 'veryo-quote__cite' ) ),
				),
				array(
					'width' => '38%',
					'inner' => veryo_b_shortcode( '[veryo_portret size="large"]' ),
				),
			)
		),
		'veryo-conviction'
	);
}
